﻿namespace WildFarm.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);
    }
}
