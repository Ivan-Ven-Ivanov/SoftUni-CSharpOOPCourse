﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}
