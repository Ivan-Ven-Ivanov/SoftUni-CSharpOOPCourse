﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
