﻿namespace Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
