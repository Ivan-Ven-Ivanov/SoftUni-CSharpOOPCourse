﻿namespace Vehicles.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);
    }
}
