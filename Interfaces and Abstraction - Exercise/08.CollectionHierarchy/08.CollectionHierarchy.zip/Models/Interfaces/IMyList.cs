﻿namespace CollectionHierarchy.Models.Interfaces
{
    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
