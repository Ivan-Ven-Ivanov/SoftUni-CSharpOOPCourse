﻿namespace BirthdayCelebrations.Models.Interfaces
{
    internal interface INameable
    {
        string Name { get; }
    }
}
