﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
