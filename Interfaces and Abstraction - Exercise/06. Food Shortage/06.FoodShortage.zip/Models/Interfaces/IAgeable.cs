﻿namespace FoodShortage.Models.Interfaces
{
    public interface IAgeable
    {
        int Age { get; }
    }
}
