﻿namespace ExplicitInterfaces.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);
    }
}
