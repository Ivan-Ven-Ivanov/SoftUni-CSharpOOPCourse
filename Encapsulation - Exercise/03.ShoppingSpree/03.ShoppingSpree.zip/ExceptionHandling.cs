﻿namespace _03.ShoppingSpree
{
    public static class ExceptionHandling
    {
        public const string NameException = "Name cannot be empty";
        public const string MoneyException = "Money cannot be negative";
    }
}
